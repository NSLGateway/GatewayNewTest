package com.nsl.pattern.util;

/**
 * ���˽s�X����
 * 
 * @author WSNPI05
 *
 */
public class Encoder {
	public String encode(String input) {
		System.out.println("encode input " + input + " done!");
		return input;
	}
}
