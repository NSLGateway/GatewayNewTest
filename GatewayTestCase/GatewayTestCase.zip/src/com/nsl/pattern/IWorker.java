package com.nsl.pattern;

import java.util.List;

public interface IWorker {

	String doA(String a);

	List<String> doB();

	int doC();

}